
x1 = float(input())
y1 = float(input())
x2 = float(input())
y2 = float(input())
m = (y2 - y1) /(x2 - x1)
print("This slope is",round(m,2))
